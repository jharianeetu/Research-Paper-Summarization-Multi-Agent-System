# summarize_and_podcast.py

import os
from agents.ingestion_agent import IngestionAgent
from agents.topic_classifier_agent import TopicClassifierAgent
from agents.summarization_agent import SummarizationAgent 
from agents.podcast_agent import PodcastAgent
from agents.search_agent import SemanticScholarSearchAgent

def ensure_output_dir(base_name):
    output_dir = os.path.join("outputs", base_name)
    os.makedirs(output_dir, exist_ok=True)
    return output_dir

def main():
    print("=== 📚 Research Paper Summarization & Podcast System ===")
    source_type = input("Enter source type (pdf, doi, url): ").strip().lower()
    source_value = input("Enter the source (file path / DOI / URL): ").strip()

    # Initialize agents
    ingestion_agent = IngestionAgent()
    classifier_agent = TopicClassifierAgent()
    summarizer_agent = SummarizationAgent()
    audio_agent = PodcastAgent()
    search_agent = SemanticScholarSearchAgent()

    # Step 1: Ingest paper content
    try:
        result = ingestion_agent.ingest(source_value, source_type=source_type)

        # Handle if ingestion failed or returned error
        if isinstance(result, dict) and "error" in result:
            print(f"❌ Ingestion failed: {result['error']}")
            return
        elif not result or not isinstance(result, str) or result.strip() == "":
            print("❌ Ingestion returned empty or invalid content.")
            return

        paper_text = result

    except Exception as e:
        print(f"❌ Ingestion crashed with exception: {e}")
        return

    # Step 2: Classify topic
    topic = classifier_agent.classify(paper_text)
    print(f"🧠 Predicted Topic: {topic}")

    # Step 3: Summarize
    summary = summarizer_agent.summarize(paper_text)
    print("\n📄 Summary:\n", summary)

    # Step 4: Generate podcast audio
    base_name = os.path.splitext(os.path.basename(source_value))[0] if source_type == "pdf" else topic.replace(" ", "_")
    output_dir = ensure_output_dir(base_name)
    audio_path = os.path.join(output_dir, "summary_audio.mp3")
    audio_agent.generate(summary, audio_path)
    print(f"🔊 Audio podcast saved at: {audio_path}")

    # Step 5: Save summary text
    summary_path = os.path.join(output_dir, "summary.txt")
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("Predicted Topic: " + topic + "\n\n")
        f.write(summary)
    print(f"📝 Summary saved at: {summary_path}")

    print("\n✅ Process completed successfully!")

if __name__ == "__main__":
    main()
