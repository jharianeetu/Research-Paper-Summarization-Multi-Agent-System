# test_search.py

from agents.search_agent import SemanticScholarSearchAgent

search_agent = SemanticScholarSearchAgent(max_results=5)

topic = "Generative AI in Education"
results = search_agent.search(topic, filter_by="citations")

for idx, paper in enumerate(results, start=1):
    print(f"\n📄 Paper {idx}")
    print(f"Title: {paper['title']}")
    print(f"Authors: {', '.join(paper['authors'])}")
    print(f"Year: {paper['year']}")
    print(f"Venue: {paper['venue']}")
    print(f"Citations: {paper['citationCount']}")
    print(f"URL: {paper['url']}")
    print(f"Abstract: {paper['abstract'][:300]}...")
