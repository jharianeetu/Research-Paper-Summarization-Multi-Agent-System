import os
import tempfile
import requests
from agents.ingestion_agent import IngestionAgent
from agents.topic_classifier_agent import TopicClassifierAgent
from agents.summarization_agent import SummarizationAgent
from agents.podcast_agent import PodcastAgent

def main():
    print("🚀 Research Paper Summarizer Multi-Agent System")

    # Prompt user for input
    input_source = input("Enter PDF path or direct PDF URL: ").strip()

    # Ingestion Agent
    ingestion_agent = IngestionAgent()
    try:
        if input_source.startswith("http"):
            print(f"🌐 Downloading PDF from URL: {input_source}")
            response = requests.get(input_source)
            if response.status_code == 200:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
                    tmp_file.write(response.content)
                    local_pdf_path = tmp_file.name
                print(f"📎 PDF downloaded to temp path: {local_pdf_path}")
            else:
                print("❌ Failed to download PDF.")
                return
        else:
            local_pdf_path = input_source

        print(f"📥 Reading local PDF using pdfplumber: {local_pdf_path}")
        extracted_text = ingestion_agent.ingest(local_pdf_path)
    except Exception as e:
        print(f"❌ Ingestion failed: {e}")
        return

    # Topic Classification Agent
    classifier = TopicClassifierAgent()
    topic = classifier.classify(extracted_text)
    print(f"🧠 Topic classified as: {topic}")

    # Prepare output directory structure
    topic_safe = topic.replace(" ", "_")
    output_dir = os.path.join("output", topic_safe)
    os.makedirs(output_dir, exist_ok=True)

    # Summarization Agent
    summarizer = SummarizationAgent()
    summary = summarizer.summarize(extracted_text)
    print("\n📄 Summary:\n", summary)

    # Save summary as text file
    summary_path = os.path.join(output_dir, "summary.txt")
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(summary)
    print(f"📁 Summary saved to: {summary_path}")

    # Cross-Paper Synthesis (optional for single PDF)
    synthesis = summarizer.synthesize([extracted_text])
    print("\n🔗 Cross-Paper Synthesis:\n", synthesis)

    # Podcast Agent
    podcast_agent = PodcastAgent()
    audio_path = os.path.join(output_dir, "summary.mp3")
    podcast_agent.generate(summary, audio_path)
    print(f"\n🎧 Podcast audio saved to: {audio_path}")

if __name__ == "__main__":
    main()
