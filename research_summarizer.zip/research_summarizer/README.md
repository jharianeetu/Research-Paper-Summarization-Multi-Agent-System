# Research Paper Summarization Multi-Agent System

## Description
A system that finds, summarizes, organizes, and creates podcast versions of research papers using a LangChain-based multi-agent system.

## Tech Stack
- **Frontend**: Streamlit
- **Backend**: Python
- **Agents**: LangChain
- **Summarization**: Hugging Face Transformers
- **Audio Generation**: gTTS
- **Paper Search**: Semantic Scholar API
- **Citation Management**: BibTeX via DOI

## Setup Instructions

```bash
git clone <your_repo_url>
cd research_summarizer
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
