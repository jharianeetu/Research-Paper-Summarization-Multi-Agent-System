from agents.summarization_agent import SummarizationAgent

# Replace with actual long text from your ingestion agent
long_text = """
In recent years, deep learning models have been widely used for natural language processing tasks...
(more text here)
"""

summarizer = SummarizationAgent()
summary = summarizer.summarize(long_text)
print("\n🧠 Summary:\n", summary)
