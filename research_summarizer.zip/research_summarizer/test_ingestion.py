# test_ingestion.py
from agents.ingestion_agent import IngestionAgent

if __name__ == "__main__":
    ingestion_agent = IngestionAgent()
    result = ingestion_agent.ingest("sample.pdf", source_type="pdf")  # replace with your PDF path

    print("✅ Ingestion successful. Metadata:")
    print(result["metadata"])
    print("\n📄 Extracted Text (first 500 chars):")
    print(result["text"][:500])
