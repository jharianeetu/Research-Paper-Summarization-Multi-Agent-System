from agents.topic_classifier_agent import TopicClassifierAgent

text = """We propose a novel transformer-based architecture that improves text classification accuracy in NLP tasks."""
classifier = TopicClassifierAgent()
topic = classifier.classify(text)

print(f"🧠 Predicted Topic: {topic}")
