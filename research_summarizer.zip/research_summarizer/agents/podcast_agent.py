# agents/podcast_agent.py

from gtts import gTTS
import os

class PodcastAgent:
    def __init__(self, lang='en'):
        """
        Initializes the PodcastAgent with a language setting.
        Default language is English ('en').
        """
        self.lang = lang

    def generate(self, text, output_path):
        """
        Generates an audio podcast from the given text using gTTS and saves it to the specified path.

        Parameters:
            text (str): The summary text to convert to speech.
            output_path (str): The path where the audio file will be saved (should end with .mp3).
        """
        print("🎙️ Generating podcast audio...")

        if not text or not isinstance(text, str):
            print("❌ Error: No valid text provided for audio generation.")
            return

        if not output_path.endswith('.mp3'):
            print("❌ Error: Output file must end with .mp3")
            return

        try:
            tts = gTTS(text=text, lang=self.lang)
            tts.save(output_path)
            print(f"✅ Audio saved to: {output_path}")
        except Exception as e:
            print(f"❌ Error generating audio: {e}")
