# agents/search_agent.py

import requests

class SemanticScholarSearchAgent:
    BASE_URL = "https://api.semanticscholar.org/graph/v1/paper/search"
    
    def __init__(self, fields=None, max_results=10):
        self.fields = fields or [
            "title", "abstract", "authors", "year", "url", "venue", "citationCount"
        ]
        self.max_results = max_results
    
    def search(self, query, filter_by="relevance"):
        """
        Search Semantic Scholar for papers based on query.
        
        :param query: The topic or keyword (e.g., "LLM for education")
        :param filter_by: "relevance", "recency", or "citations"
        :return: List of dictionaries (papers)
        """
        params = {
            "query": query,
            "limit": self.max_results,
            "fields": ",".join(self.fields),
        }

        response = requests.get(self.BASE_URL, params=params)
        
        if response.status_code != 200:
            raise Exception(f"Semantic Scholar API error: {response.status_code}")
        
        data = response.json()
        papers = data.get("data", [])
        
        # Sort if needed
        if filter_by == "recency":
            papers = sorted(papers, key=lambda x: x.get("year", 0), reverse=True)
        elif filter_by == "citations":
            papers = sorted(papers, key=lambda x: x.get("citationCount", 0), reverse=True)
        
        return self._format_results(papers)

    def _format_results(self, papers):
        """
        Format raw API response into clean paper objects.
        """
        formatted = []
        for paper in papers:
            authors = [a['name'] for a in paper.get("authors", [])]
            formatted.append({
                "title": paper.get("title"),
                "abstract": paper.get("abstract"),
                "authors": authors,
                "year": paper.get("year"),
                "venue": paper.get("venue"),
                "url": paper.get("url"),
                "citationCount": paper.get("citationCount")
            })
        return formatted
