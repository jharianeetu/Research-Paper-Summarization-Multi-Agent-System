# agents/summarization_agent.py

from transformers import pipeline
import torch
import re

class SummarizationAgent:
    def __init__(self, model_name="facebook/bart-large-cnn"):
        device = 0 if torch.cuda.is_available() else -1
        print(f"📚 Loading summarization model...")
        self.summarizer = pipeline("summarization", model=model_name, device=device)
        self.max_chunk_len = 1000  # max input length in characters per chunk

    def split_into_chunks(self, text, chunk_size=1000):
        # Split text into chunks based on sentence boundaries
        sentences = re.split(r'(?<=[.!?]) +', text)
        chunks = []
        current_chunk = ""

        for sentence in sentences:
            if len(current_chunk) + len(sentence) <= chunk_size:
                current_chunk += sentence + " "
            else:
                chunks.append(current_chunk.strip())
                current_chunk = sentence + " "
        
        if current_chunk:
            chunks.append(current_chunk.strip())

        return chunks

    def summarize(self, text, max_length=150, min_length=40):
        chunks = self.split_into_chunks(text, self.max_chunk_len)
        print(f"📝 Summarizing {len(chunks)} chunk(s)...")

        summaries = []
        for i, chunk in enumerate(chunks):
            print(f"   → Summarizing chunk {i + 1}/{len(chunks)}...")
            summary = self.summarizer(
                chunk,
                max_length=max_length,
                min_length=min_length,
                do_sample=False
            )[0]["summary_text"]
            summaries.append(summary)

        final_summary = "\n\n".join(summaries)
        return final_summary

    def synthesize(self, texts):
        print(f"🔗 Synthesizing {len(texts)} paper(s)...")
        combined_text = "\n\n".join(texts)
        return self.summarize(combined_text)
