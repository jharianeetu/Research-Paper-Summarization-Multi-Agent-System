import pdfplumber
import requests
import tempfile

class IngestionAgent:
    def ingest(self, source, source_type="pdf"):
        """
        Main dispatcher for ingestion based on source type.
        """
        if source_type == "pdf":
            return self.ingest_pdf(source)
        elif source_type == "url":
            if source.lower().endswith(".pdf"):
                return self.ingest_pdf_from_url(source)
            elif "semanticscholar.org/paper/" in source:
                return self.ingest_semanticscholar_url(source)
            else:
                print(f"🌐 URL ingestion not fully implemented for non-PDF URLs: {source}")
                return {"error": "Unsupported URL format (only .pdf or Semantic Scholar supported for now)"}
        elif source_type == "doi":
            print("📄 DOI ingestion not yet implemented.")
            return {"error": "DOI ingestion not implemented"}
        else:
            raise ValueError(f"❌ Unsupported source type: {source_type}")

    def ingest_pdf(self, filepath):
        """
        Reads a local PDF and returns extracted text using pdfplumber.
        """
        print(f"📥 Reading local PDF using pdfplumber: {filepath}")
        try:
            text = ""
            with pdfplumber.open(filepath) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
            return text.strip()
        except Exception as e:
            print(f"❌ Failed to read local PDF: {e}")
            return {"error": str(e)}

    def ingest_pdf_from_url(self, pdf_url):
        """
        Downloads a PDF from a URL, extracts and returns text using pdfplumber.
        """
        print(f"🌐 Downloading PDF from URL: {pdf_url}")
        try:
            response = requests.get(pdf_url)
            response.raise_for_status()

            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
                tmp_file.write(response.content)
                tmp_path = tmp_file.name

            print(f"📎 PDF downloaded to temp path: {tmp_path}")
            return self.ingest_pdf(tmp_path)

        except Exception as e:
            print(f"❌ Failed to download or process PDF from URL: {e}")
            return {"error": str(e)}

    def ingest_semanticscholar_url(self, paper_url):
        """
        Resolves a Semantic Scholar paper URL to an open access PDF if available.
        """
        print(f"🔍 Trying to resolve Semantic Scholar paper URL: {paper_url}")
        try:
            paper_id = paper_url.rstrip("/").split("/")[-1]
            api_url = f"https://api.semanticscholar.org/graph/v1/paper/{paper_id}?fields=title,openAccessPdf"
            response = requests.get(api_url)
            response.raise_for_status()
            data = response.json()

            pdf_link = data.get("openAccessPdf", {}).get("url")
            if not pdf_link:
                print("❌ No PDF found via Semantic Scholar API.")
                return {"error": "No open access PDF available."}

            print(f"📎 Found PDF link: {pdf_link}")
            return self.ingest_pdf_from_url(pdf_link)

        except Exception as e:
            print(f"❌ Failed to resolve Semantic Scholar link: {e}")
            return {"error": str(e)}
