from transformers import pipeline

class TopicClassifierAgent:
    def __init__(self):
        self.classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")
        self.labels = [
            "Machine Learning", "Computer Vision", "Natural Language Processing",
            "Robotics", "Cybersecurity", "Cloud Computing", "Software Engineering"
        ]

    def classify(self, text):
        result = self.classifier(text, self.labels)
        return result["labels"][0]  # return top label
