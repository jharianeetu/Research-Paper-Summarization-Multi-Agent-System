from agents.podcast_agent import PodcastAgent

text = """
This paper presents a novel approach to natural language understanding using deep learning techniques...
"""

agent = PodcastAgent()
agent.text_to_speech(text, "output_summary.mp3")
